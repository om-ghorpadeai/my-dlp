# My DLP — Pruthvi Group

Mobile-first Daily Lesson Plan web app based on the supplied weekly timetable.

## Run
Open `index.html` in a browser.

## Features
- Monday–Saturday timetable
- Mobile-first layout
- Create/edit/delete DLP for every period
- Saves DLPs in the browser using localStorage
- No database required for the first version

## Next step
Publish this folder with GitHub Pages to make it accessible online from your aunt's phone.
